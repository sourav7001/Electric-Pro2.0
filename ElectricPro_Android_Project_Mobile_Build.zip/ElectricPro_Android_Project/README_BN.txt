Electric Pro — Android Studio Source Project

এই ZIP-এ Android অ্যাপের SOURCE PROJECT আছে; এটি APK ফাইল নয়।

অ্যাপে বর্তমানে:
- House wiring estimate calculator
- Customer record save (এই ফোন/অ্যাপের ভেতরে)
- Estimate history
- Browser print dialog-এর মাধ্যমে Save PDF চেষ্টা
- Call / WhatsApp link
- Yellow + black theme

গুরুত্বপূর্ণ সীমাবদ্ধতা:
1. Customer ও estimate data এই ডিভাইসের অ্যাপের local storage-এ থাকে।
2. অন্য ফোনে auto-sync / cloud backup এখনো নেই।
3. এই project-এ APK আগে থেকে build করা নেই।
4. Google Play Store-এ প্রকাশ করা হয়নি।
5. Print-to-PDF আচরণ Android/WebView ডিভাইস অনুযায়ী পরীক্ষা করতে হবে।

APK বানানোর সহজ পথ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP extract করুন।
3. Android Studio → Open → extract করা ElectricPro folder বেছে নিন।
4. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
5. Build → Build APK(s) নির্বাচন করুন।
6. Build সফল হলে Android Studio-তে “locate” চাপলে APK ফাইলের অবস্থান দেখাবে।
7. APK নিজের ফোনে ইনস্টল করে পরীক্ষা করুন।

প্রথমবার build করতে ইন্টারনেট প্রয়োজন হতে পারে, কারণ Android Studio Gradle/Android plugin ডাউনলোড করতে পারে।

Package name: com.sourav.electricpro
App name: Electric Pro
Version: 1.0


মোবাইল দিয়ে Cloud Build (GitHub Actions):
1. GitHub-এ সাইন ইন করে New repository তৈরি করুন (Public বা Private)।
2. এই ZIP ফোনে extract করুন; GitHub-এর ওয়েবসাইটে repository-তে ফাইলগুলো upload করুন। .github/workflows/build-apk.yml ফাইলটি-সহ সব ফাইল আপলোড হতে হবে।
3. Upload শেষে repository-র Actions tab খুলুন। Workflow অনুমতি চাইলে Enable/Allow করুন।
4. main branch-এ workflow push করলে স্বয়ংক্রিয়ভাবে চলবে; অথবা Actions → Build Electric Pro APK → Run workflow চাপুন।
5. সবুজ Success হলে run খুলুন; নিচে Artifacts থেকে ElectricPro-debug-APK ডাউনলোড করুন। ZIP artifact extract করলে app-debug.apk পাবেন।
6. APK ইনস্টল করার আগে Android-এর browser/files app-কে “Install unknown apps” অনুমতি দিতে হতে পারে। শুধু নিজের তৈরি ও বিশ্বাসযোগ্য APK ইনস্টল করুন।

সতর্কতা:
- GitHub account প্রয়োজন; public repository হলে source সবার দেখা যেতে পারে। Customer data বা secret কখনও source repository-তে রাখবেন না।
- এটি debug APK; Play Store release-ready signed AAB নয়।
- Workflow সফল হওয়া নিশ্চিত নয়; build error হলে error log দেখে ঠিক করতে হবে।
